
# ⚠️NOTE

This plugin is a library! It does not do anything by itself, but other plugins can use it for configuration purposes. See the wiki for more information.

# Installation
Download the zip file and put PluginConfigurator folder inside ULTRAKILL/BepInEx/plugins. In game, config menu can be accessed from Settings/PLUGIN CONFIG\
![](https://i.ibb.co/VLKyL0v/Screenshot-2023-10-08-124111.png)

# Presets
Settings can be saved in different presets (like profiles). To access presets, click the top button in a plugin panel.\
![](https://i.ibb.co/4jZGRgp/presets.png)\
In the preset panel, you can switch, create, rename, reorder, reset and delete presets. Pressing the create preset button (+) copies the current preset.
![](https://i.ibb.co/1zLhRRw/presetpanel.png)

# GITHUB

https://github.com/eternalUnion/UKPluginConfigurator
